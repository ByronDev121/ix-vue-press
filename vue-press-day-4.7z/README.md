# Ixperience Software Engineering - 2024

## Vue press

Additional resource for the 2024 SE course.

## Deployment

.git in src/.vuepress/dist (origin  https://github.com/ByronDev121/ix-vue-press.git)

## URL

https://byrondev121.github.io/ix-vue-press/capstone-project/